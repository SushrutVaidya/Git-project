package com.psl.jpaApp.dao;

//import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.psl.jpaApp.employee;

//interface to apply crud repository functions available in spring boot
public interface EmployeeRepo extends CrudRepository<employee, Integer> {
//	List<employee> findByTech(String TECH_STACK);

}
