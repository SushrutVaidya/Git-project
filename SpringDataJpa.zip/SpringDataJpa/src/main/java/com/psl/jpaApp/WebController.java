/*This controller class contains the mapping for all the webpages 
 * the controllers are for creation / deletion / fetching the data from the database */

package com.psl.jpaApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.psl.jpaApp.dao.EmployeeRepo;

@Controller
public class WebController {
	@Autowired
	EmployeeRepo repo;

//mapping for home page of the application 
	@GetMapping("/home")
	public String home() {
		return "home";
	}

//mapping for the add employee section 
	@GetMapping("/addEmp")
	public String AddEmp(employee Emp) {
		repo.save(Emp);
		return "home";
	}

//mapping for the fetching the employee details 
	@GetMapping("/GetEmp")
	public ModelAndView GetEmp(@RequestParam int empid) {
		ModelAndView mv = new ModelAndView();
		employee emp = repo.findById(empid).orElse(null);
		mv.addObject("emp", emp);
		mv.setViewName("GetEmp");
//		System.out.println(repo.findByTech("java"));
		return mv;
	}

//mapping for the deletion of employee record
	@GetMapping("/DelEmp")
	public ModelAndView DelEmp(@RequestParam int empid) {
		ModelAndView del = new ModelAndView();
		repo.deleteById(empid);
		del.addObject("emp", empid);
		del.setViewName("DelEmp");
		return del;

	}

	@GetMapping(path = "/updateEmp", consumes = "application/json")
	public ModelAndView updateEmp(@RequestBody employee emp) {
		ModelAndView update = new ModelAndView();
		employee emp1 = repo.findById(emp.getEmpid()).orElse(null);
		if (emp1 != null) {
			repo.save(emp);
		} else {
			update.addObject("Msg", "Employee not found");

		}
		update.addObject("Msg", " Employee updated sucessfully");
		update.setViewName("UpdateEmp");
		return update;

	}

}
