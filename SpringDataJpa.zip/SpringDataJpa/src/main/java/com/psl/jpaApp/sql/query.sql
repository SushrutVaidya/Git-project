insert into Emp_Psl values(001,'Sushrut','java');
insert into Emp_Psl values(002,'Vajra','.NET');
insert into Emp_Psl values(001,'Chaitanya','Python');
insert into Emp_Psl values(001,'Siddesh','C++');
insert into Emp_Psl values(001,'Vikram','Sales Force');