/*This class contains the employee variables as well as 
 * the marking this class as the entity class which will indicate spring boot to 
 * create a table which will be fed to the H2 database server */

package com.psl.jpaApp;

//import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "Emp_Psl")
public class employee {

//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private Integer empid;
	private String empName;
//	@Column(name = "TECH_STACK")
	private String techStack;

	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "employee [empid=" + empid + ", empName=" + empName + ", techStack=" + techStack + "]";
	}

	public String getTechStack() {
		return techStack;
	}

	public void setTechStack(String techStack) {
		this.techStack = techStack;
	}
}
