package com.psl.MoneyControl.Service;



import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.psl.MoneyControl.Model.MidCapFund;
import com.psl.MoneyControl.Repo.MidCapFundRepo;
import com.psl.MoneyControl.Utility.StringFormatter;

@Service
public class MidCapFundService {
    
    @Autowired
    private MidCapFundRepo repo;

    @Scheduled(cron = "0 15 10 15 * ?")//scheduled for every month 15th, at 10;15 am
    public void getStocks(){
        final String url = "https://www.moneycontrol.com/mutual-funds/performance-tracker/returns/mid-cap-fund.html";
        List<String> title = new ArrayList<String>();
        try {
            final Document document = Jsoup.connect(url).get();
            for(Element row: document.select("table.mctable1 tr")){
                MidCapFund m = new MidCapFund();
                String schemeName =  row.select("td:nth-of-type(1)").text();
                if(schemeName.equals("")) {
                    continue;
                }
                schemeName = schemeName.substring(0, schemeName.indexOf('-'));
                m.setSchemeName(schemeName);

                if(title.contains(schemeName)) {
                    continue;
                }
                title.add(schemeName);

                String auM =  row.select("td:nth-of-type(5)").text();
                auM = auM.equals("-")?"0":auM.replace(",", "");

                String col1W = row.select("td:nth-of-type(6)").text();
                String col1M = row.select("td:nth-of-type(7)").text();
                String col3M = row.select("td:nth-of-type(8)").text();
                String col6M = row.select("td:nth-of-type(9)").text();
                String col1Y = row.select("td:nth-of-type(11)").text();
                String col2Y = row.select("td:nth-of-type(12)").text();
                String col3Y = row.select("td:nth-of-type(13)").text();
                String col5Y = row.select("td:nth-of-type(14)").text();
                String col10Y = row.select("td:nth-of-type(15)").text();

                double marketValue = Double.parseDouble(auM);
                double oneWeek =  StringFormatter.convertToDouble(col1W);
                double oneMonth =  StringFormatter.convertToDouble(col1M);
                double threeMonth =  StringFormatter.convertToDouble(col3M);
                double sixMonth =  StringFormatter.convertToDouble(col6M);
                double oneYear =  StringFormatter.convertToDouble(col1Y);
                double twoYear =  StringFormatter.convertToDouble(col2Y);
                double threeYear =  StringFormatter.convertToDouble(col3Y);
                double fiveYear =  StringFormatter.convertToDouble(col5Y);
                double tenYear =  StringFormatter.convertToDouble(col10Y);

                m.setMarketValue(marketValue);
                m.setOneWeek(oneWeek);
                m.setOneMonth(oneMonth);
                m.setThreeMonth(threeMonth);
                m.setSixMonth(sixMonth);
                m.setOneYear(oneYear);
                m.setTwoYear(twoYear);
                m.setThreeYear(threeYear);
                m.setFiveYear(fiveYear);
                m.setTenYear(tenYear);

                repo.save(m);
                }
                
            }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
