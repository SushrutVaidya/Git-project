package com.psl.MoneyControl.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.psl.MoneyControl.Service.LargeCapFundService;
import com.psl.MoneyControl.Service.MidCapFundService;
import com.psl.MoneyControl.Service.SmallCapFundService;

@RestController
public class MoneyAppController {


    @Autowired
    SmallCapFundService sService;
    @Autowired
    MidCapFundService mService;
    @Autowired
    LargeCapFundService lService;
 
    @RequestMapping("/funds")
    public void getStocks(){
        sService.getStocks();
        mService.getStocks();
        lService.getStocks();
    }
}
