package com.psl.MoneyControl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class MyMoneyControlAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyMoneyControlAppApplication.class, args);
	}

}
