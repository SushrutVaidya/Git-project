package com.psl.MoneyControl.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MidCapFund {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
    private String schemeName;
    private double marketValue;
    private double oneWeek;
    private double oneMonth;
    private double threeMonth;
    private double sixMonth;
    private double oneYear;
    private double twoYear;
    private double threeYear;
    private double fiveYear;
    private double tenYear;

    public String getSchemeName() {
        return schemeName;
    }
    public double getMarketValue() {
        return marketValue;
    }
    public double getOneWeek() {
        return oneWeek;
    }
    public double getOneMonth() {
        return oneMonth;
    }
    public double getThreeMonth() {
        return threeMonth;
    }
    public double getSixMonth() {
        return sixMonth;
    }
    public double getOneYear() {
        return oneYear;
    }
    public double getTwoYear() {
        return twoYear;
    }
    public double getThreeYear() {
        return threeYear;
    }
    public double getFiveYear() {
        return fiveYear;
    }
    public double getTenYear() {
        return tenYear;
    }
    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }
    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }
    public void setOneWeek(double oneWeek) {
        this.oneWeek = oneWeek;
    }
    public void setOneMonth(double oneMonth) {
        this.oneMonth = oneMonth;
    }
    public void setThreeMonth(double threeMonth) {
        this.threeMonth = threeMonth;
    }
    public void setSixMonth(double sixMonth) {
        this.sixMonth = sixMonth;
    }
    public void setOneYear(double oneYear) {
        this.oneYear = oneYear;
    }
    public void setTwoYear(double twoYear) {
        this.twoYear = twoYear;
    }
    public void setThreeYear(double threeYear) {
        this.threeYear = threeYear;
    }
    public void setFiveYear(double fiveYear) {
        this.fiveYear = fiveYear;
    }
    public void setTenYear(double tenYear) {
        this.tenYear = tenYear;
    }
    
    

    
}
