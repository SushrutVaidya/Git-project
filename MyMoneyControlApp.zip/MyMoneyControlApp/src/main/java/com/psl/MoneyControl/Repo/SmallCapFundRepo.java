package com.psl.MoneyControl.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.psl.MoneyControl.Model.SmallCapFund;

public interface SmallCapFundRepo extends JpaRepository<SmallCapFund,Integer>{
    
}
