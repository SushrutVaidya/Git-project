package com.psl.MoneyControl.Repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.psl.MoneyControl.Model.MidCapFund;


public interface MidCapFundRepo extends JpaRepository<MidCapFund,Integer>{
    
}
