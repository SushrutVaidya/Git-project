package com.psl.MoneyControl.Repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.psl.MoneyControl.Model.LargeCapFund;

public interface LargeCapFundRepo extends JpaRepository<LargeCapFund,Integer>{
    
}
