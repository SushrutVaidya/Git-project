package com.psl.MoneyControl.Service;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.psl.MoneyControl.Model.LargeCapFund;
import com.psl.MoneyControl.Repo.LargeCapFundRepo;
import com.psl.MoneyControl.Utility.StringFormatter;

@Service
public class LargeCapFundService {

    @Autowired
    LargeCapFundRepo repo;

    @Scheduled(cron = "0 15 10 15 * ?")//scheduled for every month 15th, at 10;15 am
    public void getStocks(){
        final String url = "https://www.moneycontrol.com/mutual-funds/performance-tracker/returns/large-cap-fund.html";
        List<String> title = new ArrayList<String>();
        try {
            final Document document = Jsoup.connect(url).get();
            for(Element row: document.select("table.mctable1 tr")){
                LargeCapFund l = new LargeCapFund();
                String schemeName =  row.select("td:nth-of-type(1)").text();
                if(schemeName.equals("")) {
                    continue;
                }
                schemeName = schemeName.substring(0, schemeName.indexOf('-'));
                l.setSchemeName(schemeName);

                if(title.contains(schemeName)) {
                    continue;
                }
                title.add(schemeName);

                String auM =  row.select("td:nth-of-type(5)").text();
                auM = auM.equals("-")?"0":auM.replace(",", "");

                String col1W = row.select("td:nth-of-type(6)").text();
                String col1M = row.select("td:nth-of-type(7)").text();
                String col3M = row.select("td:nth-of-type(8)").text();
                String col6M = row.select("td:nth-of-type(9)").text();
                String col1Y = row.select("td:nth-of-type(11)").text();
                String col2Y = row.select("td:nth-of-type(12)").text();
                String col3Y = row.select("td:nth-of-type(13)").text();
                String col5Y = row.select("td:nth-of-type(14)").text();
                String col10Y = row.select("td:nth-of-type(15)").text();

                double marketValue = Double.parseDouble(auM);
                double oneWeek =  StringFormatter.convertToDouble(col1W);
                double oneMonth =  StringFormatter.convertToDouble(col1M);
                double threeMonth =  StringFormatter.convertToDouble(col3M);
                double sixMonth =  StringFormatter.convertToDouble(col6M);
                double oneYear =  StringFormatter.convertToDouble(col1Y);
                double twoYear =  StringFormatter.convertToDouble(col2Y);
                double threeYear =  StringFormatter.convertToDouble(col3Y);
                double fiveYear =  StringFormatter.convertToDouble(col5Y);
                double tenYear =  StringFormatter.convertToDouble(col10Y);

                l.setMarketValue(marketValue);
                l.setOneWeek(oneWeek);
                l.setOneMonth(oneMonth);
                l.setThreeMonth(threeMonth);
                l.setSixMonth(sixMonth);
                l.setOneYear(oneYear);
                l.setTwoYear(twoYear);
                l.setThreeYear(threeYear);
                l.setFiveYear(fiveYear);
                l.setTenYear(tenYear);

                repo.save(l);
                }
                
            }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
