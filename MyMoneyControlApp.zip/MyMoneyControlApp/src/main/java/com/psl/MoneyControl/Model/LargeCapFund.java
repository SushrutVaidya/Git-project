package com.psl.MoneyControl.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class LargeCapFund {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int Id;
    
    private String schemeName;
    private double marketValue;
    private double oneWeek;
    private double oneMonth;
    private double threeMonth;
    private double sixMonth;
    private double oneYear;
    private double twoYear;
    private double threeYear;
    private double fiveYear;
    private double tenYear;

    public int getId() {
        return Id;
    }
    public void setId(int id) {
        Id = id;
    }
    
    public String getSchemeName() {
        return schemeName;
    }
    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }
    public double getMarketValue() {
        return marketValue;
    }
    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }
    public double getOneWeek() {
        return oneWeek;
    }
    public void setOneWeek(double oneWeek) {
        this.oneWeek = oneWeek;
    }
    public double getOneMonth() {
        return oneMonth;
    }
    public void setOneMonth(double oneMonth) {
        this.oneMonth = oneMonth;
    }
    public double getThreeMonth() {
        return threeMonth;
    }
    public void setThreeMonth(double threeMonth) {
        this.threeMonth = threeMonth;
    }
    public double getSixMonth() {
        return sixMonth;
    }
    public void setSixMonth(double sixMonth) {
        this.sixMonth = sixMonth;
    }
    public double getOneYear() {
        return oneYear;
    }
    public void setOneYear(double oneYear) {
        this.oneYear = oneYear;
    }
    public double getTwoYear() {
        return twoYear;
    }
    public void setTwoYear(double twoYear) {
        this.twoYear = twoYear;
    }
    public double getThreeYear() {
        return threeYear;
    }
    public void setThreeYear(double threeYear) {
        this.threeYear = threeYear;
    }
    public double getFiveYear() {
        return fiveYear;
    }
    public void setFiveYear(double fiveYear) {
        this.fiveYear = fiveYear;
    }
    public double getTenYear() {
        return tenYear;
    }
    public void setTenYear(double tenYear) {
        this.tenYear = tenYear;
    }

    
}
