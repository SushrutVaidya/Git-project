package com.psl.DataREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMoneyControlAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
